/* eslint-disable */
const bgScripts = ["./static/js/305.js","./static/js/925.js","./static/js/318.js","./static/js/235.js","./static/js/170.js","./static/js/background.js"];
try { importScripts(...bgScripts);
} catch (e) { if (typeof importScripts === "function") console.error(e);}
if (typeof module !== "undefined") { module.exports = { bgScripts }; }