(()=>{try{let h=typeof window<"u"?window:typeof global<"u"?global:typeof globalThis<"u"?globalThis:typeof self<"u"?self:{},v=new h.Error().stack;v&&(h._sentryDebugIds=h._sentryDebugIds||{},h._sentryDebugIds[v]="62f96828-b451-4c8c-a548-e0b025a1b238",h._sentryDebugIdIdentifier="sentry-dbid-62f96828-b451-4c8c-a548-e0b025a1b238")}catch{}{let h=typeof window<"u"?window:typeof global<"u"?global:typeof globalThis<"u"?globalThis:typeof self<"u"?self:{};h.SENTRY_RELEASE={id:"6.24.0"}}(()=>{"use strict";var h={48944:(o,s,e)=>{e.d(s,{BA:()=>i,CY:()=>K,Ct:()=>z,EZ:()=>C,Et:()=>p,GY:()=>b,JO:()=>L,Kz:()=>D,Mz:()=>M,NA:()=>y,O_:()=>$,Ro:()=>P,UU:()=>W,Vl:()=>j,WZ:()=>N,W_:()=>w,Wo:()=>B,ZZ:()=>U,hT:()=>R,tT:()=>A,wB:()=>u,wx:()=>G});var c=e(28159),a=e(78990);function d(O){return(0,c.A)(O)&&O.length>0}const A="https://cloud.argent-api.com/v1",i=d(A),r=i?(0,a.A)(A,"tokens/prices?chain=starknet"):void 0,m=i?(0,a.A)(A,"tokens/info?chain=starknet"):void 0,E=i?(0,a.A)(A,"tokens/scamTokenReports"):void 0,t=i?(0,a.A)(A,"reviewer"):void 0,g=d(t)?(0,a.A)(t,"transactions/v2/review/starknet"):void 0,B="https://healthcheck.argent.xyz/argentx/status.json",p=d(B),u="https://healthcheck.argent.xyz/argentx/promotions.json",b=d(u),f=null,w=i?(0,a.A)(A,"explorer/starknet"):void 0,_=d(w),x=i?(0,a.A)(A,"multisig/starknet/"):void 0,y=d(x)?x:void 0,S=i?(0,a.A)(A,"tokens/dapps"):void 0,k=i?(0,a.A)(A,"account"):void 0,R=i?(0,a.A)(A,"explorer/discover/starknet"):void 0,P=i?(0,a.A)(A,"explorer/discover/starknet/2fa"):void 0,C=y?(0,a.A)(y):void 0,F=i?(0,a.A)(A,"tokens/swap"):void 0,V=i?(0,a.A)(A,"promo/submitSwap"):void 0,U="https://www.argent.xyz/legal/privacy/argent-x/",M="https://www.argent.xyz/legal/argent-extension-terms-of-service/",$=!0,Y=i?(0,a.A)(A,"status/starknet"):void 0,L=!0,N=!!(typeof window<"u"&&window.PLAYWRIGHT),D="https://portfolio.argent.xyz/overview/",G="https://portfolio.hydrogen.argent47.net/overview/",z=i?(0,a.A)(A,"affiliate/referral"):void 0,X="MISSING_ENV_VAR".ARGENT_OPTIMIZER_URL??"https://content.argent.net/image",W=i?(0,a.A)(A,"accounts/starknet"):void 0,j=i?(0,a.A)(A,"accounts"):void 0,K=i?(0,a.A)(A,"name-resolution","resolve"):void 0,H=null,Z=null,J=null,Q=i?(0,a.A)(A,"/tokens/graph"):void 0,q=i?(0,a.A)(A,"/tokens/info"):void 0,AA=i?(0,a.A)(A,"/tokens/defi"):void 0,tA=i?(0,a.A)(A,"/relayer/paymaster"):void 0},44330:(o,s,e)=>{e.d(s,{z:()=>c});function c(a){return a.runtime.getManifest().manifest_version===2?a.browserAction:a.action}},33896:(o,s,e)=>{e.d(s,{A:()=>A});var c=e(44330),a=e(75748),d=e(33835);class A{constructor(r,m=a.oo){this.browser=r,this.connectId=m}setDefaultPopup(r="index.html"){return(0,c.z)(this.browser).setPopup({popup:r})}unsetDefaultPopup(){return this.setDefaultPopup("")}async setDefaultSidePanel(r="index.html"){const m=!!r;await this.browser.sidePanel.setOptions({path:r,enabled:m}),await this.browser.sidePanel.setPanelBehavior({openPanelOnActionClick:m})}async unsetDefaultSidePanel(){return this.setDefaultSidePanel("")}async openSidePanel(){const r=await this.browser.windows.getCurrent();r?.id&&await this.browser.sidePanel.open({windowId:r.id})}async createTab(r="index.html"){const m=this.browser.runtime.getURL(r);return this.browser.tabs.create({url:m})}async getTab(){const[r]=await this.browser.tabs.query({url:[this.browser.runtime.getURL("/*")]});return r}isExcludedFullScreenRoute(r){try{let E=new URL(r).pathname;E=E.replace(/\/?index\.html$/,""),E.startsWith("/")||(E="/"+E);for(const t of d.fK){const n=t.startsWith("/")?t:"/"+t;if(E.startsWith(n))return!0}return!1}catch{return!1}}async hasTab(){const r=await this.getTab();return!r||!r.id||!r.windowId?!1:!(r.url&&this.isExcludedFullScreenRoute(r.url))}async focusTab(){const r=await this.getTab();r&&r.id&&r.windowId&&(await this.browser.windows.update(r.windowId,{focused:!0}),await this.browser.tabs.update(r.id,{active:!0}))}async getFloatingWindow(){const[r]=await this.browser.windows.getAll({windowTypes:["popup"]});return r}async hasFloatingWindow(){return!!await this.getFloatingWindow()}async focusFloatingWindow(){const r=await this.getFloatingWindow();r&&r.id&&await this.browser.windows.update(r.id,{focused:!0})}async closeFloatingWindow(){const r=await this.getFloatingWindow();r?.id&&await this.browser.windows.remove(r.id)}}},75748:(o,s,e)=>{e.d(s,{Dl:()=>i,bX:()=>A,oo:()=>d});var c=e(83346),a=e.n(c);const d="argent-x-ui-service-connect",A=!0,i=!!a().sidePanel},19893:(o,s,e)=>{e.d(s,{K:()=>A});var c=e(83346),a=e.n(c),d=e(33896);const A=new d.A(a())},33835:(o,s,e)=>{e.d(s,{JZ:()=>m,fK:()=>E});var c=e(28159),a=e(72106),d=e(85371);const A=(...[t,n])=>(0,c.A)(t)?Object.defineProperty(()=>t,"path",{value:t}):Object.defineProperty(t,"path",{value:n}),i=t=>{const n=g=>g?`${t}?returnTo=${encodeURIComponent(g)}`:t;return n.path=t,n},r=t=>{const n=(0,a.A)(t,d.A);return new URLSearchParams(n).toString()},m={onboardingStart:A("/onboarding/start"),onboardingDisclaimer:A("/onboarding/disclaimer"),onboardingPrivacy:A(t=>`/onboarding/privacy/${t}`,"/onboarding/privacy/:path"),onboardingPassword:A("/onboarding/password"),onboardingFinish:A("/onboarding/finish"),onboardingRestoreBackup:A("/onboarding/restore/backup"),onboardingRestoreSeed:A("/onboarding/restore/seed"),onboardingRestorePassword:A("/onboarding/restore/password"),onboardingAccountType:A("/onboarding/account-type"),onboardingSmartAccountEmail:A("/onboarding/smart-account/email"),onboardingSmartAccountOTP:A(t=>`/onboarding/smart-account/otp?email=${encodeURIComponent(t)}`,"onboarding/smart-account/otp/"),setupRecovery:i("/recovery"),setupSeedRecovery:i("/recovery/seed"),confirmSeedRecovery:i("/recovery/seed/confirm"),accountTokens:A("/account/tokens"),accountCollections:A("/account/collections"),accountActivity:A("/account/activity"),accountDiscover:A("/account/discover"),beforeYouContinue:A("/before-you-continue"),collectionNfts:A((t,n)=>n?`/account/collection/${t}?returnTo=${encodeURIComponent(n)}`:`/account/collection/${t}`,"/account/collection/:contractAddress"),accountNft:A((t,n,g)=>g?`/account/nfts/${t}/${n}?returnTo=${encodeURIComponent(g)}`:`/account/nfts/${t}/${n}`,"/account/nfts/:contractAddress/:tokenId"),accountHideOrDeleteConfirm:A((t,n)=>`/account/hide-or-remove-confirm/${t}/${n}`,"/account/hide-or-remove-confirm/:accountId/:mode"),sendRecipientScreen:A(t=>`/send?${r(t)}`,"/send"),sendAddressBookEdit:A(t=>`/send/address-book/edit?${r(t)}`,"/send/address-book/edit"),sendAmountAndAssetScreen:A(t=>`/send/amount-and-asset/?${r(t)}`,"/send/amount-and-asset"),sendAssetScreen:A(t=>`/send/asset/?${r(t)}`,"/send/asset"),sendCollectionsNftsScreen:A(t=>`/send/collections-nfts/?${r(t)}`,"/send/collections-nfts"),transactionDetail:A((t,n)=>n?`/account/activity/${t}?returnTo=${encodeURIComponent(n)}`:`/account/activity/${t}`,"/account/activity/:txHash"),accountDeprecated:A("/account/account-deprecated"),accountOwnerWarning:i("/account/account-owner-warning"),accountsHidden:A((t,n)=>n?`/accounts/hidden/${t}?returnTo=${encodeURIComponent(n)}`:`/accounts/hidden/${t}`,"/accounts/hidden/:networkId"),accounts:i("/accounts"),newAccount:A((t,n)=>n?`/accounts/new/${t}?returnTo=${encodeURIComponent(n)}`:`/accounts/new/${t}`,"/accounts/new/:networkId"),changeAccountImplementations:A(t=>`/accounts/${t}/change-implementation`,"/accounts/:accountId/change-implementation"),accountImplementation:A(t=>`/accounts/${t}/implementation`,"/accounts/:accountId/implementation"),addAccount:A("/accounts/new"),standardAccountSignerSelection:A("/account/standard/signer-selection"),smartAccountStart:A(t=>`/accounts/${t}/smartAccount`,"/accounts/:accountId/smartAccount"),argentAccountEmail:A((t,n,g)=>g?`/accounts/${t}/${n}/email?returnTo=${encodeURIComponent(g)}`:`/accounts/${t}/${n}/email`,"/accounts/:accountId/:flow/email"),argentAccountLoggedIn:A(t=>`/accounts/${t}/logged-in`,"/accounts/:accountId/logged-in"),smartAccountOTP:A((t,n,g)=>`/accounts/${t}/${g}/otp?email=${encodeURIComponent(n)}`,"/accounts/:accountId/:flow/otp"),createSmartAccountOTP:A((t,n)=>`/accounts/${n}/otp?email=${encodeURIComponent(t)}`,"/accounts/:flow/otp"),createSmartAccountEmail:A(t=>t?`/accounts/email?returnTo=${encodeURIComponent(t)}`:"/accounts/email","/accounts/email"),smartAccountAction:A(t=>`/accounts/${t}/smartAccount/action`,"/accounts/:accountId/smartAccount/action"),smartAccountFinish:A(t=>`/accounts/${t}/smartAccount/finish`,"/accounts/:accountId/smartAccount/finish"),smartAccountEscapeWarning:A(t=>`/accounts/${t}/smartAccount/escape-warning`,"/accounts/:accountId/smartAccount/escape-warning"),newToken:A("/tokens/new"),funding:A("/funding"),fundingBridge:A("/funding/bridge"),exportPrivateKey:A((t,n)=>`/export-private-key/${t}/${n}`,"/export-private-key/:accountId/:type"),exportPublicKey:A(t=>`/export-public-key/${t}`,"/export-public-key/:accountId"),fundingQrCode:A("/funding/qr-code"),fundingProvider:A((t,n)=>n?`/funding/provider/${t}?returnTo=${encodeURIComponent(n)}`:`/funding/provider/${t}`,"/funding/provider/:tokenAddress?"),fundingFaucetFallback:A("/funding/faucet-fallback"),fundingFaucetSepolia:A("/funding/faucet-sepolia"),hideToken:A(t=>`/tokens/${t}/hide`,"/tokens/:tokenAddress/hide"),addPlugin:A(t=>`/add-plugin/${t}`,"/add-plugin/:accountId"),reset:A("/reset"),legacy:A("/legacy"),settings:i("/settings"),settingsAccount:A((t,n)=>n?`/settings/account/${t}?returnTo=${encodeURIComponent(n)}`:`/settings/account/${t}`,"/settings/account/:accountId"),settingsPreferences:i("/settings/preferences"),settingsBlockExplorer:i("/settings/preferences/block-explorer"),settingsNftMarketplace:i("/settings/preferences/nft-marketplace"),settingsIdProvider:i("/settings/preferences/id-provider"),settingsLanguage:i("/settings/preferences/language"),settingsHiddenAndSpamTokens:i("/settings/preferences/hidden-and-spam-tokens"),settingsNetworks:A("/settings/advanced/networks"),settingsSeed:i("/settings/seed"),settingsAutoLockTimer:i("/settings/auto-lock-timer"),settingsAddCustomNetwork:A("/settings/advanced/networks/add"),settingsEditCustomNetwork:A(t=>`/settings/advanced/networks/${t}/edit`,"/settings/advanced/networks/:networkId/edit"),settingsRemoveCustomNetwork:A("/settings/advanced/networks/remove"),settingsAuthorizedDappsAccountList:A("/settings/dapp-connections"),settingsAuthorizedDappsAccount:A(t=>`/settings/dapp-connections/${t}`,"/settings/dapp-connections/:accountId"),settingsSecurityAndRecovery:i("/settings/security-and-recovery"),settingsPrivacy:i("/settings/privacy"),settingsAdvanced:A("/settings/advanced"),settingsExperimental:A("/settings/advanced/experimental"),settingsBetaFeatures:A("/settings/advanced/beta-features"),settingsAddressBook:A("/settings/addressbook"),settingsSecurityPeriod:A("/settings/security-period"),settingsRemoveGuardian:A("/settings/remove-guardian"),settingsAddressBookAddOrEdit:A(t=>`/settings/addressbook/add-or-edit?${r(t)}`,"/settings/addressbook/add-or-edit"),settingsClearLocalStorage:A("/settings/clear-local-storage"),settingsDownloadLogs:A("/settings/download-logs"),deploymentData:A("/settings/deployment-data"),networkWarning:i("/network-warning"),backupDownload:A(t=>`/backup-download${t?"?settings":""}`,"/backup-download"),userReview:A("/user-review"),userReviewFeedback:A("/user-review/feedback"),backgroundError:A("/background-error"),error:A("/error"),ledgerConnect:A((t,n,g,B)=>`/ledger/connect/${t}/${n}/${g}/${B}`,"/ledger/connect/:accountType/:networkId/:ctx/:signerToReplace"),ledgerSelect:A("/ledger/select"),ledgerDone:A("/ledger/done"),multisigNew:A("/account/new/multisig"),multisigSetup:A("/multisig/setup"),multisigSignerSelection:A((t,n)=>`/multisig/signer-selection/${t}/${n}`,"/multisig/signer-selection/:ctx/:signerToReplace"),multisigCreate:A((t,n)=>`/multisig/create/${t}/${n}`,"/multisig/create/:networkId/:creatorType"),multisigJoin:A(t=>`/multisig/join/${t}`,"/multisig/join/:publicKey"),multisigJoinSettings:A((t,n)=>n?`/multisig/join/${t}/settings?returnTo=${encodeURIComponent(n)}`:`/multisig/join/${t}/settings`,"/multisig/join/:publicKey/settings"),multisigOwners:A(t=>`/multisig/${t}/owners`,"/multisig/:accountId/owners"),multisigConfirmations:A(t=>`/multisig/${t}/confirmations`,"/multisig/:accountId/confirmations"),multisigAddOwners:A(t=>`/multisig/${t}/add-owners`,"/multisig/:accountId/add-owners"),multisigRemoveOwners:A((t,n)=>`/multisig/${t}/${n}/remove-owners`,"/multisig/:accountId/:signerToRemove/remove-owners"),multisigReplaceOwner:A((t,n)=>`/multisig/${t}/${n}/replace-owner`,"/multisig/:accountId/:signerToReplace/replace-owner"),multisigPendingTransactionDetails:A((t,n,g)=>g?`/multisig/transactions/${t}/${n}/details?returnTo=${encodeURIComponent(g)}`:`/multisig/transactions/${t}/${n}/details`,"/multisig/transactions/:accountId/:requestId/details"),multisigTransactionConfirmations:A((t,n,g)=>`/multisig/${t}/${n}/${g}/confirmations`,"/multisig/:accountId/:requestId/:transactionType/confirmations"),multisigRemovedSettings:A((t,n)=>n?`/multisig/removed/${t}/settings?returnTo=${encodeURIComponent(n)}`:`/multisig/removed/${t}/settings`,"/multisig/removed/:accountId/settings"),multisigPendingOffchainSignatureDetails:A((t,n)=>`/multisig/signatures/${t}/${n}/details`,"/multisig/signatures/:accountId/:requestId/details"),tokenDetails:A((t,n,g=m.accountTokens())=>`/token/${t}/${n}?returnTo=${encodeURIComponent(g)}`,"/token/:address/:networkId"),multisigPendingOffchainSignatureConfirmations:A((t,n)=>`/multisig/signatures/${t}/${n}/confirmations`,"/multisig/signatures/:accountId/:requestId/confirmations"),multisigOffchainSignatureWarning:A("/multisig/signatures/warning"),airGapReview:A(t=>`/airgap/${t}`,"/airgap/:data"),privateKeyImport:i("/account/pk-import"),swapToken:A((t,n,g,B)=>{const p=new URLSearchParams;t&&p.append("payToken",t),n&&p.append("returnTo",n),g&&p.append("payAmount",g),B&&p.append("receiveToken",B);const u=p.toString();return`/swap${u?`?${u}`:""}`},"/swap"),swapSettings:i("/swap-settings"),openedLootbox:A((t,n,g,B,p)=>n&&g&&B&&p?`/lootbox?state=${encodeURIComponent(t)}&tokenAddress=${encodeURIComponent(n)}&prizeAmount=${encodeURIComponent(g)}&prizeUsdAmount=${encodeURIComponent(B)}&prizeThreshold=${encodeURIComponent(p)}`:`/lootbox?state=${encodeURIComponent(t)}`,"/lootbox"),staking:i("/staking"),nativeStakingIndex:i("/staking/native"),nativeStaking:A((t,n)=>n?`/staking/native${t?`/${t}`:""}?returnTo=${encodeURIComponent(n)}`:`/staking/native${t?`/${t}`:""}`,"/staking/native/:investmentId?"),nativeStakingSelect:i("/staking/native-select"),liquidStakingIndex:i("/staking/liquid"),liquidStaking:A((t,n)=>n?`/staking/liquid${t?`/${t}`:""}?returnTo=${encodeURIComponent(n)}`:`/staking/liquid${t?`/${t}`:""}`,"/staking/liquid/:investmentId?"),liquidStakingSelect:i("/staking/liquid-select"),nativeUnstake:A((t,n)=>n?`/staking/unstake-native/${t}?returnTo=${encodeURIComponent(n)}`:`/staking/unstake-native/${t}`,"/staking/unstake-native/:investmentPositionId"),liquidUnstake:A((t,n)=>n?`/staking/unstake-liquid/${t}?returnTo=${encodeURIComponent(n)}`:`/staking/unstake-liquid/${t}`,"/staking/unstake-liquid/:investmentPositionId"),defiPositionDetails:A((t,n,g)=>g?`/defi/position/${t}/${n}?returnTo=${encodeURIComponent(g)}`:`/defi/position/${t}/${n}`,"/defi/position/:positionId/:dappId"),editAccountLabel:A(t=>`/account-labels/edit/${t}`,"/account-labels/edit/:accountId")},E=["/background-error","/error","/reset","/onboarding/start","/onboarding/privacy/","/onboarding/password","/onboarding/restore/backup","/onboarding/restore/seed","/onboarding/restore/password","/onboarding/finish","/onboarding/account-type","/onboarding/smart-account/email","onboarding/smart-account/otp/","/user-review","/user-review/feedback","/multisig/create/","/ledger/connect/","/airgap/"]},27004:(o,s,e)=>{var c=e(76656),a=e(26282),d=e.n(a),A=e(62955),i=e.n(A),r=e(92777),m=e.n(r),E=e(38450),t=e.n(E),n=e(85598),g=e.n(n),B=e(32163),p=e.n(B),u=e(78880),b={};b.styleTagTransform=p(),b.setAttributes=t(),b.insert=m().bind(null,"head"),b.domAPI=i(),b.insertStyleElement=g();var f=d()(u.A,b);const w=u.A&&u.A.locals?u.A.locals:void 0;var _=e(22155),x=e(58997),T=e(48944),y=e(50269);const S=(0,_.lazy)(()=>Promise.all([e.e(693),e.e(701),e.e(365),e.e(982),e.e(424),e.e(93),e.e(707),e.e(969)]).then(e.bind(e,6334)).then(C=>({default:C.App}))),k=document.getElementById("root");if(!k)throw new Error("No root element found");const R=!1;T.BA,y.V.registerUIProcess(),(0,x.H)(k).render((0,c.jsx)(_.StrictMode,{children:(0,c.jsx)(S,{})}))},588:(o,s,e)=>{e.d(s,{V:()=>g});var c=e(35589),a=e(6201),d=e.n(a),A=e(69492),i=e(71197),r=e(83346),m=e.n(r);const E=m().runtime.connect();let t=(0,c.d)({transformer:i.Ay,links:[(0,a.chromeLink)({port:E})]});if(typeof window>"u")throw new Error("This file should only be imported in the UI");(0,A.l7)(E,()=>m().runtime.connect(),B=>{B.name,t=(0,c.d)({transformer:i.Ay,links:[(0,a.chromeLink)({port:B})]})});const n=(B=[])=>({get:function(p,u){const b=["mutate","query","subscription"].includes(u),f=typeof p[u]=="object"&&p[u]!==null||typeof p[u]=="function";return b||!f?[...B,u].reduce((w,_)=>w[_],t):new Proxy(p[u],n([...B,u]))}}),g=new Proxy(t,n())},57452:(o,s,e)=>{e.d(s,{C:()=>c,F:()=>a});const c=Symbol("Navigate"),a=Symbol("ShowNotification")},50269:(o,s,e)=>{e.d(s,{V:()=>B});var c=e(83346),a=e.n(c),d=e(11164),A=e(19893),i=e(69492);function r(p){const u=p.origin??p.url;if(!u)throw new Error("Message sender has no origin or url");const{origin:b}=new URL(u);return b}function m(p){const b=a().runtime.getURL("").replace(/\/$/,"");return r(p)===b}var E=e(57452),t=e(588);class n{constructor(u,b,f){this.emitter=u,this.browser=b,this.uiService=f,this.initMessageListeners()}initMessageListeners(){this.browser.runtime.onMessage.addListener((u,b,f)=>{if(m(b))switch(u.type){case"HAS_POPUP":f(this.hasPopup());break;case"CLOSE_POPUP":this.closePopup();break;case"NAVIGATE":this.emitter.emit(E.C,u.payload);break;case"SHOW_NOTIFICATION":this.emitter.emit(E.F,u.payload);break;default:}})}registerUIProcess(){(0,i.um)(()=>this.browser.runtime.connect({name:this.uiService.connectId}),()=>{})}getPopup(){const[u]=this.browser.extension.getViews({type:"popup"});return u}hasPopup(){return!!this.getPopup()}closePopup(){const u=this.getPopup();u&&u.close()}async onNotificationClicked(u){await t.V.notifications.notificationClicked.mutate(u)}async openUiAsPopup(){await t.V.ui.openUiAsPopup.query()}}const g=new d.A,B=new n(g,a(),A.K)},78880:(o,s,e)=>{e.d(s,{A:()=>m});var c=e(65284),a=e.n(c),d=e(28348),A=e.n(d),i=e(9343),r=A()(a());r.i(i.A),r.push([o.id,`*, ::before, ::after {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}

::backdrop {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}/*
! tailwindcss v3.4.17 | MIT License | https://tailwindcss.com
*//*
1. Prevent padding and border from affecting element width. (https://github.com/mozdevs/cssremedy/issues/4)
2. Allow adding a border to an element by just adding a border-width. (https://github.com/tailwindcss/tailwindcss/pull/116)
*/

*,
::before,
::after {
  box-sizing: border-box; /* 1 */
  border-width: 0; /* 2 */
  border-style: solid; /* 2 */
  border-color: #e5e7eb; /* 2 */
}

::before,
::after {
  --tw-content: '';
}

/*
1. Use a consistent sensible line-height in all browsers.
2. Prevent adjustments of font size after orientation changes in iOS.
3. Use a more readable tab size.
4. Use the user's configured \`sans\` font-family by default.
5. Use the user's configured \`sans\` font-feature-settings by default.
6. Use the user's configured \`sans\` font-variation-settings by default.
7. Disable tap highlights on iOS
*/

html,
:host {
  line-height: 1.5; /* 1 */
  -webkit-text-size-adjust: 100%; /* 2 */
  -moz-tab-size: 4; /* 3 */
  tab-size: 4; /* 3 */
  font-family: Barlow, sans-serif; /* 4 */
  font-feature-settings: normal; /* 5 */
  font-variation-settings: normal; /* 6 */
  -webkit-tap-highlight-color: transparent; /* 7 */
}

/*
1. Remove the margin in all browsers.
2. Inherit line-height from \`html\` so users can set them as a class directly on the \`html\` element.
*/

body {
  margin: 0; /* 1 */
  line-height: inherit; /* 2 */
}

/*
1. Add the correct height in Firefox.
2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)
3. Ensure horizontal rules are visible by default.
*/

hr {
  height: 0; /* 1 */
  color: inherit; /* 2 */
  border-top-width: 1px; /* 3 */
}

/*
Add the correct text decoration in Chrome, Edge, and Safari.
*/

abbr:where([title]) {
  text-decoration: underline dotted;
}

/*
Remove the default font size and weight for headings.
*/

h1,
h2,
h3,
h4,
h5,
h6 {
  font-size: inherit;
  font-weight: inherit;
}

/*
Reset links to optimize for opt-in styling instead of opt-out.
*/

a {
  color: inherit;
  text-decoration: inherit;
}

/*
Add the correct font weight in Edge and Safari.
*/

b,
strong {
  font-weight: bolder;
}

/*
1. Use the user's configured \`mono\` font-family by default.
2. Use the user's configured \`mono\` font-feature-settings by default.
3. Use the user's configured \`mono\` font-variation-settings by default.
4. Correct the odd \`em\` font sizing in all browsers.
*/

code,
kbd,
samp,
pre {
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; /* 1 */
  font-feature-settings: normal; /* 2 */
  font-variation-settings: normal; /* 3 */
  font-size: 1em; /* 4 */
}

/*
Add the correct font size in all browsers.
*/

small {
  font-size: 80%;
}

/*
Prevent \`sub\` and \`sup\` elements from affecting the line height in all browsers.
*/

sub,
sup {
  font-size: 75%;
  line-height: 0;
  position: relative;
  vertical-align: baseline;
}

sub {
  bottom: -0.25em;
}

sup {
  top: -0.5em;
}

/*
1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)
2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)
3. Remove gaps between table borders by default.
*/

table {
  text-indent: 0; /* 1 */
  border-color: inherit; /* 2 */
  border-collapse: collapse; /* 3 */
}

/*
1. Change the font styles in all browsers.
2. Remove the margin in Firefox and Safari.
3. Remove default padding in all browsers.
*/

button,
input,
optgroup,
select,
textarea {
  font-family: inherit; /* 1 */
  font-feature-settings: inherit; /* 1 */
  font-variation-settings: inherit; /* 1 */
  font-size: 100%; /* 1 */
  font-weight: inherit; /* 1 */
  line-height: inherit; /* 1 */
  letter-spacing: inherit; /* 1 */
  color: inherit; /* 1 */
  margin: 0; /* 2 */
  padding: 0; /* 3 */
}

/*
Remove the inheritance of text transform in Edge and Firefox.
*/

button,
select {
  text-transform: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Remove default button styles.
*/

button,
input:where([type='button']),
input:where([type='reset']),
input:where([type='submit']) {
  -webkit-appearance: button; /* 1 */
  background-color: transparent; /* 2 */
  background-image: none; /* 2 */
}

/*
Use the modern Firefox focus style for all focusable elements.
*/

:-moz-focusring {
  outline: auto;
}

/*
Remove the additional \`:invalid\` styles in Firefox. (https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737)
*/

:-moz-ui-invalid {
  box-shadow: none;
}

/*
Add the correct vertical alignment in Chrome and Firefox.
*/

progress {
  vertical-align: baseline;
}

/*
Correct the cursor style of increment and decrement buttons in Safari.
*/

::-webkit-inner-spin-button,
::-webkit-outer-spin-button {
  height: auto;
}

/*
1. Correct the odd appearance in Chrome and Safari.
2. Correct the outline style in Safari.
*/

[type='search'] {
  -webkit-appearance: textfield; /* 1 */
  outline-offset: -2px; /* 2 */
}

/*
Remove the inner padding in Chrome and Safari on macOS.
*/

::-webkit-search-decoration {
  -webkit-appearance: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Change font properties to \`inherit\` in Safari.
*/

::-webkit-file-upload-button {
  -webkit-appearance: button; /* 1 */
  font: inherit; /* 2 */
}

/*
Add the correct display in Chrome and Safari.
*/

summary {
  display: list-item;
}

/*
Removes the default spacing and border for appropriate elements.
*/

blockquote,
dl,
dd,
h1,
h2,
h3,
h4,
h5,
h6,
hr,
figure,
p,
pre {
  margin: 0;
}

fieldset {
  margin: 0;
  padding: 0;
}

legend {
  padding: 0;
}

ol,
ul,
menu {
  list-style: none;
  margin: 0;
  padding: 0;
}

/*
Reset default styling for dialogs.
*/
dialog {
  padding: 0;
}

/*
Prevent resizing textareas horizontally by default.
*/

textarea {
  resize: vertical;
}

/*
1. Reset the default placeholder opacity in Firefox. (https://github.com/tailwindlabs/tailwindcss/issues/3300)
2. Set the default placeholder color to the user's configured gray 400 color.
*/

input::placeholder,
textarea::placeholder {
  opacity: 1; /* 1 */
  color: #9ca3af; /* 2 */
}

/*
Set the default cursor for buttons.
*/

button,
[role="button"] {
  cursor: pointer;
}

/*
Make sure disabled buttons don't get the pointer cursor.
*/
:disabled {
  cursor: default;
}

/*
1. Make replaced elements \`display: block\` by default. (https://github.com/mozdevs/cssremedy/issues/14)
2. Add \`vertical-align: middle\` to align replaced elements more sensibly by default. (https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210)
   This can trigger a poorly considered lint error in some tools but is included by design.
*/

img,
svg,
video,
canvas,
audio,
iframe,
embed,
object {
  display: block; /* 1 */
  vertical-align: middle; /* 2 */
}

/*
Constrain images and videos to the parent width and preserve their intrinsic aspect ratio. (https://github.com/mozdevs/cssremedy/issues/14)
*/

img,
video {
  max-width: 100%;
  height: auto;
}

/* Make elements with the HTML hidden attribute stay hidden by default */
[hidden]:where(:not([hidden="until-found"])) {
  display: none;
}

:root {
  --css-interop-darkMode: class dark;
  --css-interop: true;
  --css-interop-nativewind: true;
}
  * {
  }
  html {
  overflow: hidden;
  background-color: var(--color-surface-default);
  color: var(--color-text-primary);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  caret-color: var(--color-text-brand);
}
  body {
  overflow: hidden;
  font-family: Barlow, sans-serif;
}
.\\!container {
  width: 100% !important;
}
.container {
  width: 100%;
}
@media (min-width: 640px) {

  .\\!container {
    max-width: 640px !important;
  }

  .container {
    max-width: 640px;
  }
}
@media (min-width: 768px) {

  .\\!container {
    max-width: 768px !important;
  }

  .container {
    max-width: 768px;
  }
}
@media (min-width: 1024px) {

  .\\!container {
    max-width: 1024px !important;
  }

  .container {
    max-width: 1024px;
  }
}
@media (min-width: 1280px) {

  .\\!container {
    max-width: 1280px !important;
  }

  .container {
    max-width: 1280px;
  }
}
@media (min-width: 1536px) {

  .\\!container {
    max-width: 1536px !important;
  }

  .container {
    max-width: 1536px;
  }
}
.visible {
  visibility: visible;
}
.static {
  position: static;
}
.fixed {
  position: fixed;
}
.absolute {
  position: absolute;
}
.relative {
  position: relative;
}
.inset-0 {
  inset: 0px;
}
.bottom-0 {
  bottom: 0px;
}
.left-0 {
  left: 0px;
}
.right-0 {
  right: 0px;
}
.top-0 {
  top: 0px;
}
.mx-2 {
  margin-left: 0.5rem;
  margin-right: 0.5rem;
}
.ml-1 {
  margin-left: 0.25rem;
}
.ml-auto {
  margin-left: auto;
}
.block {
  display: block;
}
.inline-block {
  display: inline-block;
}
.inline {
  display: inline;
}
.flex {
  display: flex;
}
.inline-flex {
  display: inline-flex;
}
.grid {
  display: grid;
}
.contents {
  display: contents;
}
.hidden {
  display: none;
}
.size-10 {
  width: 2.5rem;
  height: 2.5rem;
}
.size-4 {
  width: 1rem;
  height: 1rem;
}
.size-6 {
  width: 1.5rem;
  height: 1.5rem;
}
.size-7 {
  width: 1.75rem;
  height: 1.75rem;
}
.h-10 {
  height: 2.5rem;
}
.h-12 {
  height: 3rem;
}
.h-3 {
  height: 0.75rem;
}
.h-3\\.5 {
  height: 0.875rem;
}
.h-4 {
  height: 1rem;
}
.h-6 {
  height: 1.5rem;
}
.h-7 {
  height: 1.75rem;
}
.min-h-12 {
  min-height: 3rem;
}
.min-h-8 {
  min-height: 2rem;
}
.min-h-\\[26px\\] {
  min-height: 26px;
}
.w-10 {
  width: 2.5rem;
}
.w-12 {
  width: 3rem;
}
.w-3\\.5 {
  width: 0.875rem;
}
.w-4 {
  width: 1rem;
}
.w-6 {
  width: 1.5rem;
}
.w-7 {
  width: 1.75rem;
}
.w-full {
  width: 100%;
}
.grow {
  flex-grow: 1;
}
.transform {
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.resize {
  resize: both;
}
.flex-row {
  flex-direction: row;
}
.flex-col {
  flex-direction: column;
}
.items-end {
  align-items: flex-end;
}
.items-center {
  align-items: center;
}
.justify-center {
  justify-content: center;
}
.justify-between {
  justify-content: space-between;
}
.gap-0\\.5 {
  gap: 0.125rem;
}
.gap-1 {
  gap: 0.25rem;
}
.gap-2 {
  gap: 0.5rem;
}
.gap-3 {
  gap: 0.75rem;
}
.self-start {
  align-self: flex-start;
}
.overflow-hidden {
  overflow: hidden;
}
.text-ellipsis {
  text-overflow: ellipsis;
}
.whitespace-nowrap {
  white-space: nowrap;
}
.break-all {
  word-break: break-all;
}
.rounded {
  border-radius: 0.25rem;
}
.rounded-full {
  border-radius: 9999px;
}
.rounded-lg {
  border-radius: 0.5rem;
}
.rounded-md {
  border-radius: 0.375rem;
}
.rounded-xl {
  border-radius: 0.75rem;
}
.border {
  border-width: 1px;
}
.border-b-\\[3px\\] {
  border-bottom-width: 3px;
}
.border-t {
  border-top-width: 1px;
}
.border-brand {
  border-color: var(--color-text-brand);
}
.border-stroke-focused {
  border-color: var(--color-stroke-focused);
}
.border-surface-default {
  border-color: var(--color-surface-default);
}
.border-transparent {
  border-color: transparent;
}
.bg-accent-brand {
  background-color: var(--color-accent-brand);
}
.bg-accent-green {
  background-color: var(--color-accent-green);
}
.bg-accent-hot-pink {
  background-color: var(--color-accent-hot-pink);
}
.bg-accent-sky-blue {
  background-color: var(--color-accent-sky-blue);
}
.bg-accent-yellow {
  background-color: var(--color-accent-yellow);
}
.bg-button-danger {
  background-color: var(--color-button-danger);
}
.bg-button-info {
  background-color: var(--color-button-info);
}
.bg-button-primary {
  background-color: var(--color-button-primary);
}
.bg-button-secondary {
  background-color: var(--color-button-secondary);
}
.bg-button-secondary-hover {
  background-color: var(--color-button-secondary-hover);
}
.bg-button-tertiary {
  background-color: var(--color-button-tertiary);
}
.bg-button-warning {
  background-color: var(--color-button-warning);
}
.bg-icon-background-brand {
  background-color: var(--color-icon-background-brand);
}
.bg-surface-default {
  background-color: var(--color-surface-default);
}
.bg-surface-elevated {
  background-color: var(--color-surface-elevated);
}
.bg-surface-sunken {
  background-color: var(--color-surface-sunken);
}
.stroke-brand {
  stroke: var(--color-text-brand);
}
.stroke-subtle {
  stroke: var(--color-text-subtle);
}
.p-0 {
  padding: 0px;
}
.p-3 {
  padding: 0.75rem;
}
.px-3 {
  padding-left: 0.75rem;
  padding-right: 0.75rem;
}
.px-4 {
  padding-left: 1rem;
  padding-right: 1rem;
}
.px-8 {
  padding-left: 2rem;
  padding-right: 2rem;
}
.py-1 {
  padding-top: 0.25rem;
  padding-bottom: 0.25rem;
}
.py-2 {
  padding-top: 0.5rem;
  padding-bottom: 0.5rem;
}
.py-3\\.5 {
  padding-top: 0.875rem;
  padding-bottom: 0.875rem;
}
.pb-2 {
  padding-bottom: 0.5rem;
}
.pb-3 {
  padding-bottom: 0.75rem;
}
.pt-1 {
  padding-top: 0.25rem;
}
.text-center {
  text-align: center;
}
.text-right {
  text-align: right;
}
.font-sans {
  font-family: Barlow, sans-serif;
}
.text-b1 {
  font-size: 1.125rem;
  line-height: 1.125rem;
  font-weight: 600;
}
.text-b2 {
  font-size: 0.9375rem;
  line-height: 1rem;
  font-weight: 600;
}
.text-b3 {
  font-size: 0.8125rem;
  line-height: 0.875rem;
  font-weight: 600;
}
.text-h5 {
  font-size: 1rem;
  line-height: 1.375rem;
  font-weight: 600;
}
.text-l1-bold {
  font-size: 0.8125rem;
  line-height: 1.125rem;
  font-weight: 600;
}
.text-l2-bold {
  font-size: 0.75rem;
  line-height: 1rem;
  font-weight: 600;
}
.text-p3 {
  font-size: 0.875rem;
  line-height: 1.3125rem;
  font-weight: 400;
}
.text-p4 {
  font-size: 0.8125rem;
  line-height: 1.25rem;
  font-weight: 400;
}
.font-bold {
  font-weight: 700;
}
.uppercase {
  text-transform: uppercase;
}
.lowercase {
  text-transform: lowercase;
}
.tabular-nums {
  --tw-numeric-spacing: tabular-nums;
  font-variant-numeric: var(--tw-ordinal) var(--tw-slashed-zero) var(--tw-numeric-figure) var(--tw-numeric-spacing) var(--tw-numeric-fraction);
}
.text-brand {
  color: var(--color-text-brand);
}
.text-danger {
  color: var(--color-text-danger);
}
.text-neutrals-400 {
  color: rgb(var(--color-neutrals-400));
}
.text-primary {
  color: var(--color-text-primary);
}
.text-secondary {
  color: var(--color-text-secondary);
}
.text-secondary-web {
  color: var(--color-text-secondary-web);
}
.text-stable {
  color: var(--color-text-stable);
}
.text-subtle {
  color: var(--color-text-subtle);
}
.text-success {
  color: var(--color-text-success);
}
.text-surface-default {
  color: var(--color-surface-default);
}
.text-surface-elevated {
  color: var(--color-surface-elevated);
}
.text-warning {
  color: var(--color-text-warning);
}
.text-white {
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
}
.underline {
  text-decoration-line: underline;
}
.line-through {
  text-decoration-line: line-through;
}
.accent-brand {
  accent-color: var(--color-text-brand);
}
.opacity-50 {
  opacity: 0.5;
}
.shadow {
  --tw-shadow: 0px 1px 4px rgba(0, 0, 0, 0.35);
  --tw-shadow-colored: 0px 1px 4px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.outline {
  outline-style: solid;
}
.blur {
  --tw-blur: blur(8px);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.drop-shadow {
  --tw-drop-shadow: drop-shadow(0 1px 2px rgb(0 0 0 / 0.1)) drop-shadow(0 1px 1px rgb(0 0 0 / 0.06));
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.invert {
  --tw-invert: invert(100%);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.filter {
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.transition {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-colors {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.duration-100 {
  transition-duration: 100ms;
}
.ease-in {
  transition-timing-function: cubic-bezier(0.4, 0, 1, 1);
}
.ease-in-out {
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}
.ease-out {
  transition-timing-function: cubic-bezier(0, 0, 0.2, 1);
}
*::-webkit-scrollbar {
  height: 10px;
  width: 10px;
}
*::-webkit-scrollbar-track {
  background-color: transparent;
}
*::-webkit-scrollbar-thumb {
  border-radius: 9999px;
  border-width: 2px;
  border-style: solid;
  border-color: transparent;
  background-color: var(--color-button-secondary-hover);
  background-clip: padding-box;
}

.hover\\:bg-button-danger-hover:hover {
  background-color: var(--color-button-danger-hover);
}

.hover\\:bg-button-info-hover:hover {
  background-color: var(--color-button-info-hover);
}

.hover\\:bg-button-primary-hover:hover {
  background-color: var(--color-button-primary-hover);
}

.hover\\:bg-button-secondary-hover:hover {
  background-color: var(--color-button-secondary-hover);
}

.hover\\:bg-button-tertiary-hover:hover {
  background-color: var(--color-button-tertiary-hover);
}

.hover\\:bg-button-warning-hover:hover {
  background-color: var(--color-button-warning-hover);
}

.focus\\:outline-none:focus {
  outline: 2px solid transparent;
  outline-offset: 2px;
}

.active\\:bg-button-danger-hover:active {
  background-color: var(--color-button-danger-hover);
}

.active\\:bg-button-info-hover:active {
  background-color: var(--color-button-info-hover);
}

.active\\:bg-button-primary-hover:active {
  background-color: var(--color-button-primary-hover);
}

.active\\:bg-button-secondary-hover:active {
  background-color: var(--color-button-secondary-hover);
}

.active\\:bg-button-tertiary-hover:active {
  background-color: var(--color-button-tertiary-hover);
}

.active\\:bg-button-warning-hover:active {
  background-color: var(--color-button-warning-hover);
}

.active\\:bg-surface-elevated:active {
  background-color: var(--color-surface-elevated);
}

.disabled\\:pointer-events-none:disabled {
  pointer-events: none;
}

.disabled\\:opacity-50:disabled {
  opacity: 0.5;
}

.web\\:pointer-events-none {
  pointer-events: none;
}
`,"",{version:3,sources:["webpack://./src/ui/globals.css"],names:[],mappings:"AAAA;EAAA,wBAAc;EAAd,wBAAc;EAAd,mBAAc;EAAd,mBAAc;EAAd,cAAc;EAAd,cAAc;EAAd,cAAc;EAAd,eAAc;EAAd,eAAc;EAAd,aAAc;EAAd,aAAc;EAAd,kBAAc;EAAd,sCAAc;EAAd,8BAAc;EAAd,6BAAc;EAAd,4BAAc;EAAd,eAAc;EAAd,oBAAc;EAAd,sBAAc;EAAd,uBAAc;EAAd,wBAAc;EAAd,kBAAc;EAAd,2BAAc;EAAd,4BAAc;EAAd,sCAAc;EAAd,kCAAc;EAAd,2BAAc;EAAd,sBAAc;EAAd,8BAAc;EAAd,YAAc;EAAd,kBAAc;EAAd,gBAAc;EAAd,iBAAc;EAAd,kBAAc;EAAd,cAAc;EAAd,gBAAc;EAAd,aAAc;EAAd,mBAAc;EAAd,qBAAc;EAAd,2BAAc;EAAd,yBAAc;EAAd,0BAAc;EAAd,2BAAc;EAAd,uBAAc;EAAd,wBAAc;EAAd,yBAAc;EAAd,sBAAc;EAAd,oBAAc;EAAd,sBAAc;EAAd,qBAAc;EAAd;AAAc;;AAAd;EAAA,wBAAc;EAAd,wBAAc;EAAd,mBAAc;EAAd,mBAAc;EAAd,cAAc;EAAd,cAAc;EAAd,cAAc;EAAd,eAAc;EAAd,eAAc;EAAd,aAAc;EAAd,aAAc;EAAd,kBAAc;EAAd,sCAAc;EAAd,8BAAc;EAAd,6BAAc;EAAd,4BAAc;EAAd,eAAc;EAAd,oBAAc;EAAd,sBAAc;EAAd,uBAAc;EAAd,wBAAc;EAAd,kBAAc;EAAd,2BAAc;EAAd,4BAAc;EAAd,sCAAc;EAAd,kCAAc;EAAd,2BAAc;EAAd,sBAAc;EAAd,8BAAc;EAAd,YAAc;EAAd,kBAAc;EAAd,gBAAc;EAAd,iBAAc;EAAd,kBAAc;EAAd,cAAc;EAAd,gBAAc;EAAd,aAAc;EAAd,mBAAc;EAAd,qBAAc;EAAd,2BAAc;EAAd,yBAAc;EAAd,0BAAc;EAAd,2BAAc;EAAd,uBAAc;EAAd,wBAAc;EAAd,yBAAc;EAAd,sBAAc;EAAd,oBAAc;EAAd,sBAAc;EAAd,qBAAc;EAAd;AAAc,CAAd;;CAAc,CAAd;;;CAAc;;AAAd;;;EAAA,sBAAc,EAAd,MAAc;EAAd,eAAc,EAAd,MAAc;EAAd,mBAAc,EAAd,MAAc;EAAd,qBAAc,EAAd,MAAc;AAAA;;AAAd;;EAAA,gBAAc;AAAA;;AAAd;;;;;;;;CAAc;;AAAd;;EAAA,gBAAc,EAAd,MAAc;EAAd,8BAAc,EAAd,MAAc;EAAd,gBAAc,EAAd,MAAc;EAAd,WAAc,EAAd,MAAc;EAAd,+BAAc,EAAd,MAAc;EAAd,6BAAc,EAAd,MAAc;EAAd,+BAAc,EAAd,MAAc;EAAd,wCAAc,EAAd,MAAc;AAAA;;AAAd;;;CAAc;;AAAd;EAAA,SAAc,EAAd,MAAc;EAAd,oBAAc,EAAd,MAAc;AAAA;;AAAd;;;;CAAc;;AAAd;EAAA,SAAc,EAAd,MAAc;EAAd,cAAc,EAAd,MAAc;EAAd,qBAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,iCAAc;AAAA;;AAAd;;CAAc;;AAAd;;;;;;EAAA,kBAAc;EAAd,oBAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,cAAc;EAAd,wBAAc;AAAA;;AAAd;;CAAc;;AAAd;;EAAA,mBAAc;AAAA;;AAAd;;;;;CAAc;;AAAd;;;;EAAA,+GAAc,EAAd,MAAc;EAAd,6BAAc,EAAd,MAAc;EAAd,+BAAc,EAAd,MAAc;EAAd,cAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,cAAc;AAAA;;AAAd;;CAAc;;AAAd;;EAAA,cAAc;EAAd,cAAc;EAAd,kBAAc;EAAd,wBAAc;AAAA;;AAAd;EAAA,eAAc;AAAA;;AAAd;EAAA,WAAc;AAAA;;AAAd;;;;CAAc;;AAAd;EAAA,cAAc,EAAd,MAAc;EAAd,qBAAc,EAAd,MAAc;EAAd,yBAAc,EAAd,MAAc;AAAA;;AAAd;;;;CAAc;;AAAd;;;;;EAAA,oBAAc,EAAd,MAAc;EAAd,8BAAc,EAAd,MAAc;EAAd,gCAAc,EAAd,MAAc;EAAd,eAAc,EAAd,MAAc;EAAd,oBAAc,EAAd,MAAc;EAAd,oBAAc,EAAd,MAAc;EAAd,uBAAc,EAAd,MAAc;EAAd,cAAc,EAAd,MAAc;EAAd,SAAc,EAAd,MAAc;EAAd,UAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;;EAAA,oBAAc;AAAA;;AAAd;;;CAAc;;AAAd;;;;EAAA,0BAAc,EAAd,MAAc;EAAd,6BAAc,EAAd,MAAc;EAAd,sBAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,aAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,gBAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,wBAAc;AAAA;;AAAd;;CAAc;;AAAd;;EAAA,YAAc;AAAA;;AAAd;;;CAAc;;AAAd;EAAA,6BAAc,EAAd,MAAc;EAAd,oBAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,wBAAc;AAAA;;AAAd;;;CAAc;;AAAd;EAAA,0BAAc,EAAd,MAAc;EAAd,aAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,kBAAc;AAAA;;AAAd;;CAAc;;AAAd;;;;;;;;;;;;;EAAA,SAAc;AAAA;;AAAd;EAAA,SAAc;EAAd,UAAc;AAAA;;AAAd;EAAA,UAAc;AAAA;;AAAd;;;EAAA,gBAAc;EAAd,SAAc;EAAd,UAAc;AAAA;;AAAd;;CAAc;AAAd;EAAA,UAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,gBAAc;AAAA;;AAAd;;;CAAc;;AAAd;;EAAA,UAAc,EAAd,MAAc;EAAd,cAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;;EAAA,eAAc;AAAA;;AAAd;;CAAc;AAAd;EAAA,eAAc;AAAA;;AAAd;;;;CAAc;;AAAd;;;;;;;;EAAA,cAAc,EAAd,MAAc;EAAd,sBAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;;EAAA,eAAc;EAAd,YAAc;AAAA;;AAAd,wEAAc;AAAd;EAAA,aAAc;AAAA;;AAAd;EAAA,kCAAc;EAAd,mBAAc;EAAd;AAAc;EAAd;EAAc;EAAd;EAAA,gBAAc;EAAd,8CAAc;EAAd,gCAAc;EAAd,mCAAc;EAAd,kCAAc;EAAd;AAAc;EAAd;EAAA,gBAAc;EAAd;AAAc;AACd;EAAA;AAAoB;AAApB;EAAA;AAAoB;AAApB;;EAAA;IAAA;EAAoB;;EAApB;IAAA;EAAoB;AAAA;AAApB;;EAAA;IAAA;EAAoB;;EAApB;IAAA;EAAoB;AAAA;AAApB;;EAAA;IAAA;EAAoB;;EAApB;IAAA;EAAoB;AAAA;AAApB;;EAAA;IAAA;EAAoB;;EAApB;IAAA;EAAoB;AAAA;AAApB;;EAAA;IAAA;EAAoB;;EAApB;IAAA;EAAoB;AAAA;AACpB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA,mBAAmB;EAAnB;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA,aAAmB;EAAnB;AAAmB;AAAnB;EAAA,WAAmB;EAAnB;AAAmB;AAAnB;EAAA,aAAmB;EAAnB;AAAmB;AAAnB;EAAA,cAAmB;EAAnB;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA,qBAAmB;EAAnB;AAAmB;AAAnB;EAAA,kBAAmB;EAAnB;AAAmB;AAAnB;EAAA,kBAAmB;EAAnB;AAAmB;AAAnB;EAAA,oBAAmB;EAAnB;AAAmB;AAAnB;EAAA,mBAAmB;EAAnB;AAAmB;AAAnB;EAAA,qBAAmB;EAAnB;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA,mBAAmB;EAAnB,qBAAmB;EAAnB;AAAmB;AAAnB;EAAA,oBAAmB;EAAnB,iBAAmB;EAAnB;AAAmB;AAAnB;EAAA,oBAAmB;EAAnB,qBAAmB;EAAnB;AAAmB;AAAnB;EAAA,eAAmB;EAAnB,qBAAmB;EAAnB;AAAmB;AAAnB;EAAA,oBAAmB;EAAnB,qBAAmB;EAAnB;AAAmB;AAAnB;EAAA,kBAAmB;EAAnB,iBAAmB;EAAnB;AAAmB;AAAnB;EAAA,mBAAmB;EAAnB,sBAAmB;EAAnB;AAAmB;AAAnB;EAAA,oBAAmB;EAAnB,oBAAmB;EAAnB;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA,kCAAmB;EAAnB;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA,oBAAmB;EAAnB;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA,4CAAmB;EAAnB,uDAAmB;EAAnB;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA,oBAAmB;EAAnB;AAAmB;AAAnB;EAAA,kGAAmB;EAAnB;AAAmB;AAAnB;EAAA,yBAAmB;EAAnB;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA,wJAAmB;EAAnB,wDAAmB;EAAnB;AAAmB;AAAnB;EAAA,+FAAmB;EAAnB,wDAAmB;EAAnB;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAmBf;EAAA,YAAwB;EAAxB;AAAwB;AAIxB;EAAA;AAAqB;AAIrB;EAAA,qBAA0G;EAA1G,iBAA0G;EAA1G,mBAA0G;EAA1G,yBAA0G;EAA1G,qDAA0G;EAA1G;AAA0G;;AA7B9G;EAAA;AAgCA;;AAhCA;EAAA;AAgCA;;AAhCA;EAAA;AAgCA;;AAhCA;EAAA;AAgCA;;AAhCA;EAAA;AAgCA;;AAhCA;EAAA;AAgCA;;AAhCA;EAAA,8BAgCA;EAhCA;AAgCA;;AAhCA;EAAA;AAgCA;;AAhCA;EAAA;AAgCA;;AAhCA;EAAA;AAgCA;;AAhCA;EAAA;AAgCA;;AAhCA;EAAA;AAgCA;;AAhCA;EAAA;AAgCA;;AAhCA;EAAA;AAgCA;;AAhCA;EAAA;AAgCA;;AAhCA;EAAA;AAgCA;;AAhCA;EAAA;AAgCA",sourcesContent:[`@tailwind base;
@tailwind components;
@tailwind utilities;

@import "@argent/x-ui/styles/tailwind.css";

@layer base {
  :root {
  }
  * {
  }
  html {
    @apply bg-surface-default text-primary caret-brand overflow-hidden antialiased;
  }
  body {
    @apply overflow-hidden font-sans;
  }
}

@layer utilities {
  *::-webkit-scrollbar {
    @apply h-[10px] w-[10px];
  }

  *::-webkit-scrollbar-track {
    @apply bg-transparent;
  }

  *::-webkit-scrollbar-thumb {
    @apply bg-button-secondary-hover rounded-full border-[2px] border-solid border-transparent bg-clip-padding;
  }
}
`],sourceRoot:""}]);const m=r}},v={};function l(o){var s=v[o];if(s!==void 0)return s.exports;var e=v[o]={id:o,loaded:!1,exports:{}};return h[o].call(e.exports,e,e.exports,l),e.loaded=!0,e.exports}l.m=h,(()=>{var o=[];l.O=(s,e,c,a)=>{if(e){a=a||0;for(var d=o.length;d>0&&o[d-1][2]>a;d--)o[d]=o[d-1];o[d]=[e,c,a];return}for(var A=1/0,d=0;d<o.length;d++){for(var[e,c,a]=o[d],i=!0,r=0;r<e.length;r++)(a&!1||A>=a)&&Object.keys(l.O).every(B=>l.O[B](e[r]))?e.splice(r--,1):(i=!1,a<A&&(A=a));if(i){o.splice(d--,1);var m=c();m!==void 0&&(s=m)}}return s}})(),l.n=o=>{var s=o&&o.__esModule?()=>o.default:()=>o;return l.d(s,{a:s}),s},(()=>{var o=Object.getPrototypeOf?e=>Object.getPrototypeOf(e):e=>e.__proto__,s;l.t=function(e,c){if(c&1&&(e=this(e)),c&8||typeof e=="object"&&e&&(c&4&&e.__esModule||c&16&&typeof e.then=="function"))return e;var a=Object.create(null);l.r(a);var d={};s=s||[null,o({}),o([]),o(o)];for(var A=c&2&&e;typeof A=="object"&&!~s.indexOf(A);A=o(A))Object.getOwnPropertyNames(A).forEach(i=>d[i]=()=>e[i]);return d.default=()=>e,l.d(a,d),a}})(),l.d=(o,s)=>{for(var e in s)l.o(s,e)&&!l.o(o,e)&&Object.defineProperty(o,e,{enumerable:!0,get:s[e]})},l.f={},l.e=o=>Promise.all(Object.keys(l.f).reduce((s,e)=>(l.f[e](o,s),s),[])),l.u=o=>""+o+".js",l.g=function(){if(typeof globalThis=="object")return globalThis;try{return this||new Function("return this")()}catch{if(typeof window=="object")return window}}(),l.o=(o,s)=>Object.prototype.hasOwnProperty.call(o,s),(()=>{var o={},s="@argent-x/extension:";l.l=(e,c,a,d)=>{if(o[e]){o[e].push(c);return}var A,i;if(a!==void 0)for(var r=document.getElementsByTagName("script"),m=0;m<r.length;m++){var E=r[m];if(E.getAttribute("src")==e||E.getAttribute("data-webpack")==s+a){A=E;break}}A||(i=!0,A=document.createElement("script"),A.charset="utf-8",A.timeout=120,l.nc&&A.setAttribute("nonce",l.nc),A.setAttribute("data-webpack",s+a),A.src=e),o[e]=[c];var t=(g,B)=>{A.onerror=A.onload=null,clearTimeout(n);var p=o[e];if(delete o[e],A.parentNode&&A.parentNode.removeChild(A),p&&p.forEach(u=>u(B)),g)return g(B)},n=setTimeout(t.bind(null,void 0,{type:"timeout",target:A}),12e4);A.onerror=t.bind(null,A.onerror),A.onload=t.bind(null,A.onload),i&&document.head.appendChild(A)}})(),l.r=o=>{typeof Symbol<"u"&&Symbol.toStringTag&&Object.defineProperty(o,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(o,"__esModule",{value:!0})},l.nmd=o=>(o.paths=[],o.children||(o.children=[]),o),l.j=792,(()=>{var o;l.g.importScripts&&(o=l.g.location+"");var s=l.g.document;if(!o&&s&&(s.currentScript&&s.currentScript.tagName.toUpperCase()==="SCRIPT"&&(o=s.currentScript.src),!o)){var e=s.getElementsByTagName("script");if(e.length)for(var c=e.length-1;c>-1&&(!o||!/^http(s?):/.test(o));)o=e[c--].src}if(!o)throw new Error("Automatic publicPath is not supported in this browser");o=o.replace(/#.*$/,"").replace(/\?.*$/,"").replace(/\/[^\/]+$/,"/"),l.p=o})(),(()=>{var o={792:0};l.f.j=(c,a)=>{var d=l.o(o,c)?o[c]:void 0;if(d!==0)if(d)a.push(d[2]);else{var A=new Promise((E,t)=>d=o[c]=[E,t]);a.push(d[2]=A);var i=l.p+l.u(c),r=new Error,m=E=>{if(l.o(o,c)&&(d=o[c],d!==0&&(o[c]=void 0),d)){var t=E&&(E.type==="load"?"missing":E.type),n=E&&E.target&&E.target.src;r.message="Loading chunk "+c+` failed.
(`+t+": "+n+")",r.name="ChunkLoadError",r.type=t,r.request=n,d[1](r)}};l.l(i,m,"chunk-"+c,c)}},l.O.j=c=>o[c]===0;var s=(c,a)=>{var[d,A,i]=a,r,m,E=0;if(d.some(n=>o[n]!==0)){for(r in A)l.o(A,r)&&(l.m[r]=A[r]);if(i)var t=i(l)}for(c&&c(a);E<d.length;E++)m=d[E],l.o(o,m)&&o[m]&&o[m][0](),o[m]=0;return l.O(t)},e=self.webpackChunk_argent_x_extension=self.webpackChunk_argent_x_extension||[];e.forEach(s.bind(null,0)),e.push=s.bind(null,e.push.bind(e))})(),l.nc=void 0;var I=l.O(void 0,[211,879],()=>l(27004));I=l.O(I)})();})();

//# sourceMappingURL=main.js.map